# cs24-p2-TEAM DEADBEEF
Hello! </br>
This is the repo for phase 2 of Code Samurai 2024 presented by Team deadbeef

Team members: </br>
#1 Md. Abu Bakor Siddique (abubakor@iut-dhaka.edu) </br>
#2 Shahrin Hossain (shahrin@iut-dhaka.edu) </br>
#3 Fateen Noor Rafee (fateennoor@gmail.com)
